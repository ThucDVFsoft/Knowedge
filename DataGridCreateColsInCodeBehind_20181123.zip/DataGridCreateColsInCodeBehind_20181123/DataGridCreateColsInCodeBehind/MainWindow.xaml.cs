﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;

namespace DataGridCreateColsInCodeBehind
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = this;
            DefineColumns();
            DefineRows();
        }

        public IEnumerable<HeaderCell> cols;
        public IEnumerable<HeaderCell> Cols
        {
            get
            {
                return cols;
            }
            set
            {
                cols = value;
                NotifyPropertyChanged("Cols");
            }
        }

        public IEnumerable<RowModel> rows;
        public IEnumerable<RowModel> Rows
        {
            get
            {
                return rows;
            }
            set
            {
                rows = value;
                NotifyPropertyChanged("Rows");
            }
        }

        private void DefineColumns()
        {
            this.Cols = new List<HeaderCell>()
            {
                new HeaderCell()
                {
                    Header = "column 1",
                    Content = "C1",
                    CellConverterKey = "SampleConverterKey",
                    CellStyleKeySelector = (Func<object, string>) (item => "CellStyle"),
                    CellTemplateKeySelector = (Func<object, string>) (item => "CellTemplate"),
                },
                new HeaderCell()
                {
                    Header = "column 2",
                    Content = "C2",
                    CellConverterKey = "SampleConverterKey",
                    CellStyleKeySelector = (Func<object, string>) (item => "CellStyle"),
                    CellTemplateKeySelector = (Func<object, string>) (item => "CellTemplate"),
                },
                new HeaderCell()
                {
                    Header = "column 3",
                    Content = "C3",
                    CellConverterKey = "SampleConverterKey",
                    CellStyleKeySelector = (Func<object, string>) (item => "CellStyle"),
                    CellTemplateKeySelector = (Func<object, string>) (item => "CellTemplate"),
                },
                new HeaderCell()
                {
                    Header = "column 4",
                    Content = "C4",
                    CellConverterKey = "SampleConverterKey",
                    CellStyleKeySelector = (Func<object, string>) (item => "CellStyle"),
                    CellTemplateKeySelector = (Func<object, string>) (item => "CellTemplate"),
                },
                new HeaderCell()
                {
                    Header = "column 5",
                    Content = "C5",
                    CellConverterKey = "SampleConverterKey",
                    CellStyleKeySelector = (Func<object, string>) (item => "CellStyle"),
                    CellTemplateKeySelector = (Func<object, string>) (item => "CellTemplate"),
                },
                new HeaderCell()
                {
                    Header = "column 6",
                    Content = "C6",
                    CellConverterKey = "SampleConverterKey",
                    CellStyleKeySelector = (Func<object, string>) (item => "CellStyle"),
                    CellTemplateKeySelector = (Func<object, string>) (item => "CellTemplate"),
                },
                new HeaderCell()
                {
                    Header = "column 7",
                    Content = "C7",
                    CellConverterKey = "SampleConverterKey",
                    CellStyleKeySelector = (Func<object, string>) (item => "CellStyle"),
                    CellTemplateKeySelector = (Func<object, string>) (item => "CellTemplate"),
                },
                new HeaderCell()
                {
                    Header = "column 8",
                    Content = "C8",
                    CellConverterKey = "SampleConverterKey",
                    CellStyleKeySelector = (Func<object, string>) (item => "CellStyle"),
                    CellTemplateKeySelector = (Func<object, string>) (item => "CellTemplate"),
                },
            };
        }

        private void DefineRows()
        {
            this.Rows = new List<RowModel>()
            {
               new RowModel()
               {
                   Item1 = "R1",
                   Key = "txt",
                   Item2 = "R1",
                   Item3 = "R1",
                   Item4 = "R1",
                   Item5 = "R1",
                   Item6 = "R1",
                   Item7 = "R1",
                   Item8 = "R1",
               },

               new RowModel()
               {
                   Item1 = "R2",
               Key = "txt",
                    Item2 = "R2",
                   Item3 = "R2",
                   Item4 = "R2",
                   Item5 = "R2",
                   Item6 = "R2",
                   Item7 = "R2",
                   Item8 = "R2",
               },

               new RowModel()
               {
                   Item1 = "R3",
               Key = "txt",
                    Item2 = "R3",
                   Item3 = "R3",
                   Item4 = "R3",
                   Item5 = "R3",
                   Item6 = "R3",
                   Item7 = "R3",
                   Item8 = "R3",
               },
               new RowModel()
               {
                   Item1 = "R4",
               Key = "txt",
                    Item2 = "R4",
                   Item3 = "R4",
                   Item4 = "R4",
                   Item5 = "R4",
                   Item6 = "R4",
                   Item7 = "R4",
                   Item8 = "R4",
               },
               new RowModel()
               {
                   Item1 = "R5",
               Key = "txt",
                    Item2 = "R5",
                   Item3 = "R5",
                   Item4 = "R5",
                   Item5 = "R5",
                   Item6 = "R5",
                   Item7 = "R5",
                   Item8 = "R5",
               },
               new RowModel()
               {
                   Item1 = "R6",
               Key = "txt",
                    Item2 = "R6",
                   Item3 = "R6",
                   Item4 = "R6",
                   Item5 = "R6",
                   Item6 = "R6",
                   Item7 = "R6",
                   Item8 = "R6",
               },
               new RowModel()
               {
                   Item1 = "R7",
               Key = "txt",
                    Item2 = "R7",
                   Item3 = "R7",
                   Item4 = "R7",
                   Item5 = "R7",
                   Item6 = "R7",
                   Item7 = "R7",
                   Item8 = "R7",
               },
               new RowModel()
               {
                   Item1 = "R8",
               Key = "txt",
                    Item2 = "R8",
                   Item3 = "R8",
                   Item4 = "R8",
                   Item5 = "R8",
                   Item6 = "R8",
                   Item7 = "R8",
                   Item8 = "R8",
               },
               new RowModel()
               {
                   Item1 = "R9",
               Key = "txt",
                    Item2 = "R9",
                   Item3 = "R9",
                   Item4 = "R9",
                   Item5 = "R9",
                   Item6 = "R9",
                   Item7 = "R9",
                   Item8 = "R9",
               },
               new RowModel()
               {
                   Item1 = "R10",
               Key = "txt",
                    Item2 = "R10",
                   Item3 = "R10",
                   Item4 = "R10",
                   Item5 = "R10",
                   Item6 = "R10",
                   Item7 = "R10",
                   Item8 = "R10",
               },
               new RowModel()
               {
                   Item1 = "R11",
               Key = "txt",
                    Item2 = "R11",
                   Item3 = "R11",
                   Item4 = "R11",
                   Item5 = "R11",
                   Item6 = "R11",
                   Item7 = "R11",
                   Item8 = "R11",
               },
               new RowModel()
               {
                   Item1 = "R12",
               Key = "txt",
                    Item2 = "R12",
                   Item3 = "R12",
                   Item4 = "R12",
                   Item5 = "R12",
                   Item6 = "R12",
                   Item7 = "R12",
                   Item8 = "R12",

               },
               new RowModel()
               {
                   Item1 = "R13",
               Key = "txt",
                    Item2 = "R13",
                   Item3 = "R13",
                   Item4 = "R13",
                   Item5 = "R13",
                   Item6 = "R13",
                   Item7 = "R13",
                   Item8 = "R13",
               },
               new RowModel()
               {
                   Item1 = "R14",
               Key = "txt",
                    Item2 = "R14",
                   Item3 = "R14",
                   Item4 = "R14",
                   Item5 = "R14",
                   Item6 = "R14",
                   Item7 = "R14",
                   Item8 = "R14",
               },
               new RowModel()
               {
                   Item1 = "R15",
               Key = "txt",
                    Item2 = "R15",
                   Item3 = "R15",
                   Item4 = "R15",
                   Item5 = "R15",
                   Item6 = "R15",
                   Item7 = "R15",
                   Item8 = "R15",
               },
            };
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            DefineColumns();
            DefineRows();
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged([CallerMemberName] String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
    public abstract class AbstractDataTemplateSelector : ContentControl
    {
        public virtual DataTemplate SelectTemplate(object item, DependencyObject container)
        {
            return null;
        }

        protected override void OnContentChanged(object oldContent, object newContent)
        {
            base.OnContentChanged(oldContent, newContent);
            ContentTemplate = SelectTemplate(newContent, this);
        }

    }
    public class ResourcesTemplateSelector : AbstractDataTemplateSelector
    {
        public static readonly DependencyProperty ResourceKeyProperty =
            DependencyProperty.Register(
            "ResourceKey", typeof(string),
            typeof(ResourcesTemplateSelector), new
            PropertyMetadata("", new PropertyChangedCallback(OnSetTextChanged)));

        private static void OnSetTextChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            
        } 


        public ResourcesTemplateSelector()
        {

        }

        public static void SetResourceKey(DependencyObject obj, string rs)
        {
            obj.SetValue(ResourceKeyProperty, rs);
        }

        public static string GetResourceKey(DependencyObject obj)
        {
            return (string)obj.GetValue(ResourceKeyProperty);
        }

        /// <summary>
        /// 設定するテンプレートのx:key
        /// 設定する際は、ResourceKeyの次に必ずContent{Binding}を記述してください。
        /// </summary>
        /// 
        public string ResourceKey
        {
            get
            {
                return (string)GetValue(ResourceKeyProperty);
            }
            set
            {
                SetValue(ResourceKeyProperty, value);
            }
        }

        public override DataTemplate SelectTemplate(object item, DependencyObject container)
        {
            if (string.IsNullOrEmpty(ResourceKey) || !Resources.Contains(ResourceKey))
            {
                return null;
                //throw new IndexOutOfRangeException("指定されたキーのリソースが見つかりませんでした。");
            }
            return Resources[ResourceKey] as DataTemplate;
        }
    }

    public class RowModel
    {
        public string Item1 { get; set; }
        public string Item2 { get; set; }
        public string Item3 { get; set; }
        public string Item4 { get; set; }
        public string Item5 { get; set; }
        public string Item6 { get; set; }
        public string Item7 { get; set; }
        public string Item8 { get; set; }

        public string Key { get; set; }
    }
}
