﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using Telerik.Windows.Controls;
using Telerik.Windows.Controls.GridView;

namespace DataGridCreateColsInCodeBehind
{
    public class GridViewColmnBinding
    {
        public static readonly DependencyProperty ColumnsSourceProperty = DependencyProperty.RegisterAttached("ColumnsSource", typeof(IEnumerable<HeaderCell>), typeof(GridViewColmnBinding), new PropertyMetadata(ColumnsSourceChanged));
        public static readonly DependencyProperty ColumnWidthProperty = DependencyProperty.RegisterAttached("ColumnWidth", typeof(GridViewLength), typeof(GridViewColmnBinding), (PropertyMetadata)null);

        public static void SetColumnWidth(DependencyObject o, GridViewLength value)
        {
            o.SetValue(GridViewColmnBinding.ColumnWidthProperty, (object)value);
        }

        public static GridViewLength GetColumnWidth(DependencyObject o)
        {
            return (GridViewLength)o.GetValue(GridViewColmnBinding.ColumnWidthProperty);
        }

        private static void ColumnsSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            GridViewDataControl grid = d as GridViewDataControl;
            if (grid == null || e.NewValue == null)
                return;
            grid.Columns.Clear();
            grid.ColumnGroups.Clear();
            IEnumerable<HeaderCell> newValue = (IEnumerable<HeaderCell>)e.NewValue;
            List<GridViewColumnGroup> gridViewColumnGroupList = new List<GridViewColumnGroup>();
            int num = 0;
            foreach (HeaderCell headerCell in newValue)
            {
                GridViewDataColumn gridViewDataColumn1 = new GridViewDataColumn();
                gridViewDataColumn1.Header = (object)headerCell.Header;
                GridViewDataColumn gridViewDataColumn2 = gridViewDataColumn1;
                if (num > 0)
                    gridViewDataColumn2.Width = GridViewColmnBinding.GetColumnWidth(d);
                if (!string.IsNullOrEmpty(headerCell.CellConverterKey))
                {
                    GridViewDataColumn gridViewDataColumn3 = gridViewDataColumn2;
                    Binding binding1 = new Binding();
                    binding1.Converter = grid.Resources[headerCell.CellConverterKey] as IValueConverter;
                    binding1.ConverterParameter = headerCell;
                    Binding binding2 = binding1;
                    gridViewDataColumn3.DataMemberBinding = binding2;
                }
                if (headerCell.CellTemplateKeySelector != null)
                    gridViewDataColumn2.CellTemplateSelector = new DataGridCreateColsInCodeBehind.abc.ResourcesDataTemplateSelector(grid.Resources)
                    {
                        ResourceKeySelector = headerCell.CellTemplateKeySelector
                    };
                if (headerCell.CellStyleKeySelector != null)
                    gridViewDataColumn2.CellStyleSelector = new ResourcesStyleSelector(grid.Resources)
                    {
                        ResourceKeySelector = headerCell.CellStyleKeySelector
                    };
                //if (headerCell.EditCellTemplateKeySelector != null)
                //{
                //    gridViewDataColumn2.CellEditTemplateSelector = new ResourcesDataTemplateSelector(grid.Resources)
                //    {
                //        ResourceKeySelector = headerCell.EditCellTemplateKeySelector
                //    };
                //}
                else
                {
                    gridViewDataColumn2.EditTriggers = GridViewEditTriggers.None;
                    gridViewDataColumn2.IsReadOnly = true;
                }
                grid.Columns.Add(gridViewDataColumn2);
                ++num;
            }
        }

        public static void SetColumnsSource(DependencyObject o, IEnumerable<HeaderCell> value)
        {
            o.SetValue(GridViewColmnBinding.ColumnsSourceProperty, (object)value);
        }

        public static IEnumerable<HeaderCell> GetColumnsSource(DependencyObject o)
        {
            return o.GetValue(GridViewColmnBinding.ColumnsSourceProperty) as IEnumerable<HeaderCell>;
        }
    }


    
    public class ResourcesStyleSelector : StyleSelector
    {
        public ResourcesStyleSelector(ResourceDictionary resources)
        {
            this.Resources = resources;
        }

        public ResourceDictionary Resources { get; private set; }

        public Func<object, string> ResourceKeySelector { get; set; }

        public override Style SelectStyle(object item, DependencyObject container)
        {
            string str = this.ResourceKeySelector != null ? this.ResourceKeySelector(item) : (string)null;
            if (!string.IsNullOrEmpty(str))
            {
                Style style = this.Resources[str] as Style;
                if (style != null)
                    return style;
            }
            return base.SelectStyle(item, container);
        }
    }
}
