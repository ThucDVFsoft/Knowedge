﻿using System;
using System.Windows;
using System.Windows.Data;
using C1.WPF.DataGrid;

namespace DataGridCreateColsInCodeBehind
{
    public class DataGridBoundTemplateColumn : DataGridTemplateColumn
    {
        public Binding Binding { get; set; }

        public override void BindCellContent(FrameworkElement cellContent, DataGridRow row)
        {
            if (Binding != null)
            {
                var stackPanel = cellContent as System.Windows.Controls.StackPanel;

                if (stackPanel != null)
                {
                    Binding newBinding = Binding.Clone();
                    newBinding.Source = row.DataItem;
                    (stackPanel as FrameworkElement).SetBinding(FrameworkElement.DataContextProperty, newBinding);
                }
            }
        }
    }

    public static class BindingExtensions
    {
        public static Binding Clone(this Binding binding)
        {
            var cloned = new Binding();

            cloned.Converter = binding.Converter;
            cloned.ConverterParameter = binding.ConverterParameter;

            return cloned;
        }
    }
}
