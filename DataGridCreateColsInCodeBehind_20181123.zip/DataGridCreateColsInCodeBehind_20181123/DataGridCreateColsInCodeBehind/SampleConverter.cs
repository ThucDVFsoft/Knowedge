﻿using System;
using System.Diagnostics;
using System.Windows.Data;

namespace DataGridCreateColsInCodeBehind
{
    public class SampleConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            HeaderCell col = parameter as HeaderCell;
            RowModel row = value as RowModel;
            if(row != null && col != null)
            {
                switch (col.Header)
                {
                    case "column 1":
                        return new Sample(row.Item1, col.Content, row.Key);
                    case "column 2":
                        return new Sample(row.Item2, col.Content, row.Key);
                    case "column 3":
                        return new Sample(row.Item3, col.Content, row.Key);
                    case "column 4":
                        return new Sample(row.Item4, col.Content, row.Key);
                    case "column 5":
                        return new Sample(row.Item5, col.Content, row.Key);
                    case "column 6":
                        return new Sample(row.Item6, col.Content, row.Key);
                    case "column 7":
                        return new Sample(row.Item7, col.Content, row.Key);
                    case "column 8":
                        return new Sample(row.Item8, col.Content, row.Key);
                    default:
                        return null;
                }
            }
            return new Sample("###", "###", "txt");
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return 0.0;
        }
    }

    public class Sample
    {
        public Sample(string str1, string str2, string key)
        {
            this.ValueAsString = str1 + "-" + str2;
        }

        public string ValueAsString { get; set; }
        public string Key { get; set; }
    }
}
