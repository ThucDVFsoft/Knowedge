﻿
using System;
namespace DataGridCreateColsInCodeBehind
{
    public class HeaderCell
    {
        public string Header
        {
            get;
            set;
        }

        public string Content
        {
            get;
            set;
        }

        public string CellConverterKey
        {
            get;
            set;
        }
        public Func<object, string> cellTemplateKeySelector;

        public Func<object, string> CellTemplateKeySelector
        {
            get
            {
                return cellTemplateKeySelector;
            }
            set
            {
                cellTemplateKeySelector = value;
            }
        }
        public Func<object, string> cellStyleKeySelector;
        public Func<object, string> CellStyleKeySelector
        {
            get
            {
                return cellStyleKeySelector;
            }
            set
            {
                cellStyleKeySelector = value;
            }
        }

    }
}
