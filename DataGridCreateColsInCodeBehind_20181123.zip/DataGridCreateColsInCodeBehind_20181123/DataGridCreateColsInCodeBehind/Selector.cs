﻿using C1.WPF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace DataGridCreateColsInCodeBehind
{
    public class ResourcesStyleSelector : C1StyleSelector
    {
        public ResourcesStyleSelector(ResourceDictionary resources)
        {
            this.Resources = resources;
        }

        public Func<object, string> ResourceKeySelector { get; set; }

        public override Style SelectStyle(object item, DependencyObject container)
        {
            string str = this.ResourceKeySelector != null ? this.ResourceKeySelector(item) : (string)null;
            if (!string.IsNullOrEmpty(str))
            {
                Style style = this.Resources[(object)str] as Style;
                if (style != null)
                    return style;
            }
            return base.SelectStyle(item, container);
        }
    }
    public class ResourcesDataTemplateSelector : C1DataTemplateSelector
    {
        public ResourcesDataTemplateSelector(ResourceDictionary resources)
        {
            this.Resources = resources;
        }
        public Func<object, string> ResourceKeySelector
        {
            get;
            set;
        }

        public override DataTemplate SelectTemplate(object item, DependencyObject container)
        {
            var key = ResourceKeySelector != null
                        ? ResourceKeySelector(item)
                        : null;
            if (!string.IsNullOrEmpty(key))
            {
                var template = this.Resources[key] as DataTemplate;
                if (template != null)
                {
                    return template;
                }
            }
            return base.SelectTemplate(item, container);
        }
    }
}
