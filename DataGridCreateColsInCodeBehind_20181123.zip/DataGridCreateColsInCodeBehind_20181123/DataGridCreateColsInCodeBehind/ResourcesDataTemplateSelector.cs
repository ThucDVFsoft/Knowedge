﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace DataGridCreateColsInCodeBehind.abc
{
    public class ResourcesDataTemplateSelector : DataTemplateSelector
    {
        public ResourcesDataTemplateSelector(ResourceDictionary resources)
        {
            this.Resources = resources;
        }

        public ResourceDictionary Resources { get; private set; }

        public Func<object, string> ResourceKeySelector { get; set; }

        public override DataTemplate SelectTemplate(object item, DependencyObject container)
        {
            string str = this.ResourceKeySelector != null ? this.ResourceKeySelector(item) : (string)null;
            if (!string.IsNullOrEmpty(str))
            {
                DataTemplate dataTemplate = this.Resources[str] as DataTemplate;
                if (dataTemplate != null)
                    return dataTemplate;
            }
            return base.SelectTemplate(item, container);
        }
    }
}
